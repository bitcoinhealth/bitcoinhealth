Sample configuration files for:
```
SystemD: buscoind.service
Upstart: buscoind.conf
OpenRC:  buscoind.openrc
         buscoind.openrcconf
CentOS:  buscoind.init
macOS:    org.buscoin.buscoind.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
