Sample configuration files for:
```
SystemD: bitcoinhealthd.service
Upstart: bitcoinhealthd.conf
OpenRC:  bitcoinhealthd.openrc
         bitcoinhealthd.openrcconf
CentOS:  bitcoinhealthd.init
macOS:    org.bitcoinhealth.bitcoinhealthd.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
